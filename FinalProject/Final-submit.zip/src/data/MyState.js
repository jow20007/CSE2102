import React from 'react';


class MyState {
    static my_attempts = null;
    static my_score = 0;
    static my_count = 0;
};

export default MyState;
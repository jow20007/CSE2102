//
// https://www.w3schools.com/REACT/react_css_styling.asp
//
const quizPageStyle = {
    color: "white"
  };


  export default quizPageStyle;
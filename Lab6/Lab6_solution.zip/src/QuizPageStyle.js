//
// https://www.w3schools.com/REACT/react_css_styling.asp
//
const quizPageStyle = {
    color: "white",
    backgroundColor: "rgb(17, 23, 56)",
    padding: "10px",
    fontFamily: "Sans-Serif"
  };


  export default quizPageStyle;